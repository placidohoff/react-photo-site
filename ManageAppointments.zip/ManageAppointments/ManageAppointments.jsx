import { useState, useEffect } from "react";
import FirebaseFirestoreService from "../../services/FirebaseFirestoreService";
import "./ManageAppointments.css";

export default function ManageAppointments() {
  const [appointmentsCollection, setAppointmentsCollection] = useState([]);
  useEffect(() => {
    fetchAppointments()
      .then((fetchedAppointments) => {
        setAppointmentsCollection(orderAppointments(fetchedAppointments));
      })
      .catch((error) => {
        console.error(error.message);
        throw error;
      });
  }, []);

  async function fetchAppointments() {
    let fetchedAppointments = [];
    const response = await FirebaseFirestoreService.readDocuments({
      collection: "Requested-Appointments",
    });

    try {
      const appointments = response.docs.map((appointmentDoc) => {
        const id = appointmentDoc.id;
        const data = appointmentDoc.data();

        return { ...data, id };
      });

      fetchedAppointments = [...appointments];
    } catch (error) {
      console.log(error.message);
      throw error;
    }

    return fetchedAppointments;
  }

  const orderAppointments = (arr) => {
    //TODO: Order by dateRequestWasMade; format dateRequestWasMa de.
    // return arr.sort((a, b) => a.displayOrder - b.displayOrder);
    return arr.sort((a, b) => a.sessionTime.seconds - b.sessionTime.seconds);
  };

  const appointmentClicked = (id) => {
    const elem = document.getElementById(id);
    alert(id);
  };

  const DisplayAppointment = ({ appointment }) => {
    let milliseconds =
      appointment.sessionTime.seconds * 1000 +
      appointment.sessionTime.nanoseconds / 1000000;
    const date = new Date(milliseconds);

    const options = {
      day: "numeric",
      month: "long",
      hour: "numeric",
      minute: "numeric",
      hour12: true,
    };

    return (
      <div
        className="displayAppointment"
        onClick={() => appointmentClicked("displayTestID")}
      >
        <div>
          Event Date: {date.toLocaleString("en-US", options)} <br />
          Event Type: {appointment.sessionType}
        </div>
        {console.log(appointment)}
      </div>
    );
  };

  return (
    <>
      <h1>Manage Appointments</h1>
      <div className="row mt-5">
        <div className="col">
          <h2>Appointment Requests</h2>
          {appointmentsCollection.map((appointment, index) => (
            <DisplayAppointment
              id={index + "testID"}
              appointment={appointment}
              key={index}
            />
          ))}
        </div>
        <div className="col">
          <h2>Approved Appointments</h2>
        </div>
      </div>
    </>
  );
}
