import sgMail from "@sendgrid/mail";

//TODO: Set as process.env
sgMail.setApiKey(
  "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"
);

export default sgMail;
