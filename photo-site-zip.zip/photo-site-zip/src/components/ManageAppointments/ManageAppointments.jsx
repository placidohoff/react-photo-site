import { useState } from "react";

export default function ManageAppointments() {
  return <h2>Manage Appointments</h2>;
}
