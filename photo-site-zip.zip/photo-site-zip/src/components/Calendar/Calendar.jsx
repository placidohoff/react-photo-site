import { useState } from "react";
import ReactCalendar from "react-calendar";
import "./Calendar.css";
import { add, format, set } from "date-fns";

export default function Calendar() {
  const [date, setDate] = useState({ day: null, time: null });
  const [day, setDay] = useState(null);
  const [time, setTime] = useState(null);

  // const [times, setTimes] = useState([]);

  const getTimes = () => {
    // if (day === null) return;
    // console.log(day + "DAY");

    const beginning = add(day, { hours: 9 });
    const end = add(day, { hours: 17 });
    const interval = 30;
    let arrTimes = [];

    for (let i = beginning; i <= end; i = add(i, { minutes: interval })) {
      arrTimes.push(i);
    }

    // setTimes(arrTimes);
    // console.log(arrTimes + "TESTING");
    return arrTimes;
  };

  const handleSetDay = (selected) => {
    setDay(selected);
    console.log(day);

    // setTimes(getTimes());
  };

  const handleSetTime = (selected, id) => {
    setTime(selected);

    const container = document.getElementById("timeslots-container");
    const elements = container.querySelectorAll("*");

    elements.forEach((element) => {
      if (element.classList.contains("time-selected")) {
        element.classList.remove("time-selected");
        // Apply your desired styles to each element
        // element.style.backgroundColor = "red";
        // You can set any other style properties as needed
      }
    });

    document.getElementById(id).classList.add("time-selected");
    console.log("Testing", id);
  };

  const times = getTimes();

  return (
    <div className="h-screen flex flex-col justify-center items-center">
      {/* {console.log(date.day)} */}
      {day === null ? (
        <ReactCalendar
          view="month"
          className="REACT-CALENDAR p-2"
          minDate={new Date()}
          onClickDay={(date) => {
            // setDay(date);\
            handleSetDay(date);
          }}
        />
      ) : (
        <div>
          <h3>
            Please select a time for {day.getMonth()}/{day.getDate()}/
            {day.getFullYear()}
          </h3>
          {/* <button onClick={() => handleSetDay(null)}>Back</button> */}
          <div
            style={{ display: "flex", overflow: "scroll", maxWidth: "500px" }}
            className="flex gap-4 p-4"
            id="timeslots-container"
          >
            {times.map((time, i) => (
              <div key={`time-${i}`}>
                <button
                  onClick={() => handleSetTime(time, `time-${i}`)}
                  className="rounded-sm bg-gray-100 p-2 REACT-CALENDAR"
                  type="button"
                  id={`time-${i}`}
                >
                  {format(time, "kk:mm")}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
