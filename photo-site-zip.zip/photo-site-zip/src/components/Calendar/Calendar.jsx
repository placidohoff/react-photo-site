import { useState } from "react";
import ReactCalendar from "react-calendar";
import "./Calendar.css";

export default function Calendar() {
  const [date, setDate] = useState({ justDate: null, dateTime: null });
  return (
    <ReactCalendar
      view="month"
      className="REACT-CALENDAR p-2"
      minDate={new Date()}
      onClickDay={(date) => console.log(date)}
    />
  );
}
