import firebase from "firebase";

const config = {
  apiKey: "AIzaSyBpBYWW0fpzvS3gRNevnrUD0ncaKBiRy3o",
  authDomain: "clear-choice-media.firebaseapp.com",
  projectId: "clear-choice-media",
  storageBucket: "clear-choice-media.appspot.com",
  messagingSenderId: "208318186628",
  appId: "1:208318186628:web:6f3f8822f83c481f05aed1",
  measurementId: "G-Z76PK9ZZZ0",
};

if (!firebase.apps.length) {
  firebase.initializeApp(config);
}

export default firebase;
